..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid7_vdst128_0:

vdst
===========================

Instruction output.

*Size:* 4 dwords.

*Operands:* :ref:`v<amdgpu_synid_v>`
