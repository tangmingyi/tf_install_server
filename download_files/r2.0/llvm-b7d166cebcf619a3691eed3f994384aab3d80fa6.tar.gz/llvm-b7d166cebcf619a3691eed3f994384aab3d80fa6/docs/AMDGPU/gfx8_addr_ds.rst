..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid8_addr_ds:

vaddr
===========================

An offset from the start of GDS/LDS memory.

*Size:* 1 dword.

*Operands:* :ref:`v<amdgpu_synid_v>`
