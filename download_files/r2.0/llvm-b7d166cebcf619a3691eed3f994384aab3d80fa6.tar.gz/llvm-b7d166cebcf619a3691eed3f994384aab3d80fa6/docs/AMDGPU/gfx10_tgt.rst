..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid10_tgt:

tgt
===========================

An export target:

    ============== ===================================
    Syntax         Description
    ============== ===================================
    pos{0..4}      Copy vertex position 0..4.
    param{0..31}   Copy vertex parameter 0..31.
    mrt{0..7}      Copy pixel color to the MRTs 0..7.
    mrtz           Copy pixel depth (Z) data.
    prim           Copy primitive (connectivity) data.
    null           Copy nothing.
    ============== ===================================

