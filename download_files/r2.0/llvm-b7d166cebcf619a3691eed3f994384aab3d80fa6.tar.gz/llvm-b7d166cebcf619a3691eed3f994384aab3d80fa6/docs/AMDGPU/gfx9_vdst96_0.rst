..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid9_vdst96_0:

vdst
===========================

Instruction output.

*Size:* 3 dwords.

*Operands:* :ref:`v<amdgpu_synid_v>`
