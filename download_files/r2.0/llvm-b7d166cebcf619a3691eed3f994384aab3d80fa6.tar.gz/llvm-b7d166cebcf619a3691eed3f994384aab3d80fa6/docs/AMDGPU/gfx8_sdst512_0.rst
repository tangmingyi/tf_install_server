..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid8_sdst512_0:

sdst
===========================

Instruction output.

*Size:* 16 dwords.

*Operands:* :ref:`s<amdgpu_synid_s>`
