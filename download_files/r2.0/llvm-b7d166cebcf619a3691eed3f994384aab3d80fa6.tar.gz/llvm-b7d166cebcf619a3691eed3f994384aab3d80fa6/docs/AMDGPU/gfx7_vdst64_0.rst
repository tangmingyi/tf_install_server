..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid7_vdst64_0:

vdst
===========================

Instruction output.

*Size:* 2 dwords.

*Operands:* :ref:`v<amdgpu_synid_v>`
