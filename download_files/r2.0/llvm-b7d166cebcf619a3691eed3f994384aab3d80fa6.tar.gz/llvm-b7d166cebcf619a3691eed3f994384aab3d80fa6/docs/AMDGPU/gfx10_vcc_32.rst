..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid10_vcc_32:

vcc
===========================

Vector condition code. This operand depends on wavefront size:

* Should be :ref:`vcc_lo<amdgpu_synid_vcc_lo>` if wavefront size is 32.
* Should be :ref:`vcc<amdgpu_synid_vcc>` if wavefront size is 64.

