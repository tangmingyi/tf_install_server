..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid7_vsrc64_0:

vsrc
===========================

Instruction input.

*Size:* 2 dwords.

*Operands:* :ref:`v<amdgpu_synid_v>`
