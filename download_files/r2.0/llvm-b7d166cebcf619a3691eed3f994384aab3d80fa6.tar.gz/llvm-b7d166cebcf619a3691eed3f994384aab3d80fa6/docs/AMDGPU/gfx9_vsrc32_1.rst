..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid9_vsrc32_1:

vsrc
===========================

Instruction input.

*Size:* 1 dword.

*Operands:* :ref:`v<amdgpu_synid_v>`, :ref:`lds_direct<amdgpu_synid_lds_direct>`
