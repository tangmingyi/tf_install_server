..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid8_data_buf_d16_64:

vdata
===========================

16-bit data to store by a buffer instruction.

*Size:* depends on GFX8 GPU revision:

* 2 dwords for GFX8.0. This H/W supports no packing.
* 1 dword for GFX8.1+. This H/W supports data packing.

*Operands:* :ref:`v<amdgpu_synid_v>`
