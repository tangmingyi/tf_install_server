..
    **************************************************
    *                                                *
    *   Automatically generated file, do not edit!   *
    *                                                *
    **************************************************

.. _amdgpu_synid10_saddr_flat_scratch:

saddr
===========================

An optional 32-bit flat scratch offset. Must be specified as :ref:`off<amdgpu_synid_off>` if not used.

Either this operand or :ref:`vaddr<amdgpu_synid10_vaddr_flat_scratch>` must be set to :ref:`off<amdgpu_synid_off>`.

*Size:* 1 dword.

*Operands:* :ref:`s<amdgpu_synid_s>`, :ref:`vcc<amdgpu_synid_vcc>`, :ref:`ttmp<amdgpu_synid_ttmp>`, :ref:`null<amdgpu_synid_null>`, :ref:`off<amdgpu_synid_off>`
